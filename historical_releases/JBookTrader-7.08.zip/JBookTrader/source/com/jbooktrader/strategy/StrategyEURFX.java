package com.jbooktrader.strategy;

import com.ib.client.*;
import com.jbooktrader.platform.commission.*;
import com.jbooktrader.platform.model.*;
import com.jbooktrader.platform.optimizer.*;
import com.jbooktrader.platform.schedule.*;
import com.jbooktrader.platform.strategy.*;
import com.jbooktrader.platform.util.*;

/**
 *
 */
public class StrategyEURFX extends Strategy {
    public StrategyEURFX(StrategyParams optimizationParams) throws JBookTraderException {
        super(optimizationParams);
        // Specify the contract to trade
        Contract contract = ContractFactory.makeCashContract("EUR", "USD");
        // Define trading schedule
        TradingSchedule tradingSchedule = new TradingSchedule("0:00", "23:59", "Europe/Berlin");
        int multiplier = 1;// contract multiplier
        double bidAskSpread = 0.0001; // prevalent spread between best
        Commission commission = CommissionFactory.getForexCommission();
        setStrategy(contract, tradingSchedule, multiplier, commission, bidAskSpread);

    }

    @Override
    public void setParams() {
    }

    @Override
    public void onBookSnapshot() {
    }
}
