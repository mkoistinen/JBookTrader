package com.jbooktrader.indicator.derivative;

import com.jbooktrader.platform.indicator.*;

/**
 * Velocity of any indicator
 */
public class Velocity2 extends Indicator {
    private final double fastMultiplier, slowMultiplier, smoothMultiplier;
    private double fast, slow;

    public Velocity2(Indicator parentIndicator, int fastPeriod, int slowPeriod, int smoothPeriod) {
        super(parentIndicator);
        fastMultiplier = 2. / (fastPeriod + 1.);
        slowMultiplier = 2. / (slowPeriod + 1.);
        smoothMultiplier = 2. / (smoothPeriod + 1.);
    }

    @Override
    public void calculate() {
        double parentValue = parentIndicator.getValue();
        fast += (parentValue - fast) * fastMultiplier;
        slow += (parentValue - slow) * slowMultiplier;
        double difference = fast - slow;
        value += (difference - value) * smoothMultiplier;
    }
}
