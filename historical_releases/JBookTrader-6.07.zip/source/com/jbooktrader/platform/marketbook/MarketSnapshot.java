package com.jbooktrader.platform.marketbook;


/**
 */
public class MarketSnapshot {
    private final long time;
    private final int balance;
    private final double price;


    public MarketSnapshot(long time, int balance, double price) {
        this.time = time;
        this.balance = balance;
        this.price = price;
    }

    public int getBalance() {
        return balance;
    }

    public long getTime() {
        return time;
    }

    public double getPrice() {
        return price;
    }

    public String toString() {
        StringBuilder marketDepth = new StringBuilder();
        marketDepth.append("time: ").append(getTime());
        marketDepth.append(" balance: ").append(balance);
        marketDepth.append(" price: ").append(price);

        return marketDepth.toString();
    }

}
